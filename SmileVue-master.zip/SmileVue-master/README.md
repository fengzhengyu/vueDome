# SmileVue 简介

> 这是一个课程项目，使用了Vue的技术，完成移动端商城的基本功能。课程60多集视频，10万字文字教程

教程地址：[点击进入：http://jspang.com/2018/04/15/vuekoa/](http://jspang.com/2018/04/15/vuekoa/)


## 项目截图

![Image text](http://7xjyw1.com1.z0.glb.clouddn.com/koa001.png)
![Image text](http://7xjyw1.com1.z0.glb.clouddn.com/koa002.png)
![Image text](http://7xjyw1.com1.z0.glb.clouddn.com/koa003.png)
![Image text](http://7xjyw1.com1.z0.glb.clouddn.com/koa004.png)

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
