export function toMoney(money = 0){
   
    return money.toFixed(2)

}