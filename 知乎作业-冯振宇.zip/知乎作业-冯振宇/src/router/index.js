import Vue from 'vue'
import Router from 'vue-router'
import Index from '../views/Index.vue'
import Detail from '../views/Detail.vue'
// import Index from '../views/Index.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: '/index'
    },
    {
      path: '/index',
      name: 'index',
      component: Index
    },
    {
      path: '/detail/:id',
      name: 'detail',
      component: Detail
    },
    {
      path: '*',
      redirect: '/index'
    }
  ]
})
