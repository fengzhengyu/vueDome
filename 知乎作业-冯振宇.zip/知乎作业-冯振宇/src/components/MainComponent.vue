<template>
  <div class="container" :class="{'show':menuState}">
    <!-- 主体内容 -->
    <slot></slot>
    <div class="news-wrap">
      <ul class="news-list">
        <li class="news-item" v-for="(news,index) in newsList" :key="index" @click="goDetail(news)">
          <h3 class="title">{{ news.title }}</h3>
          <div class="image">
           
            <span class="demonstration"></span>
             <el-image :src="news.images[0]"></el-image>
          </div>
        </li>
        
      </ul>
    </div>
    <div class="date">
      09月23日 星期一
    </div>
    <div class="news-wrap">
      <ul class="news-list">
        <li class="news-item" v-for="(item,index) in beforeNewsList" :key="index" @click="goDetail(item)">
          <h3 class="title">{{item.title }}</h3>
          <div class="image"> 
           <span class="demonstration"></span>
              <el-image :src="item.images[0]"></el-image>
          </div>
        </li>
        
        
      </ul>
    
    </div>
    <div class="no-data">你已经到底了~_~</div>
  </div>
</template>
<script>
export default {
    props: ['menuState','newsList','beforeNewsList'],
  data() {
    return {
      isShow: true
    }
  },
  methods: {
    goDetail(item){
      console.log()
      this.$router.push({
        'name': 'detail',
        params: {
          id:item.id
        }

      })
    }
  }
 
};
</script>
<style scoped>
.container {
  position: relative;
  top: 0;
  left: 0px;
  width: 100%;
 
  background: #fff;
  transition: transform 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
  overflow-x: hidden;
 
}

.container.show {
  transform: translateX(250px);
}


.news-wrap{
  padding:  15px;

}
.news-list{
  padding: 0;
}
.news-item{
  display: flex;
  padding : 15px 0;
}
.news-item .title{
  flex: 1;
  font-size: 16px;
  color: #686868;
  line-height: 20px;
  /* font-weight: normal */

  overflow: hidden;
  max-height: 60px;
}
.news-item:first-child .title{
  color: #313131;
}
.news-item .image{
  width: 75px;
  height: 60px;
  padding-left: 25px;
  line-height: 60px;
  text-align: center;
}
.news-item .image img{
  width: 100%;
  height: 100%;
}
.date{
  height: 40px;
  text-align: center;
  line-height: 40px;
  font-size: 16px;
  color: #fff;
  background: #028fd6;
}
.no-data{
  text-align: center;
  line-height: 40px;

}

</style>



