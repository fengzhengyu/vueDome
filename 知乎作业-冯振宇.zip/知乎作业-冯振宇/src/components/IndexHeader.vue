<template>
  <div class="header" :class="{'show':menuState}">
    <!-- 首页头部组件 -->
    <div class="icon" @click="tabMenu">
      <i class="el-icon-s-unfold"></i>
    </div>今日新闻
  </div>
</template>

<script>
export default {
   props:['menuState'],
   methods: {
    tabMenu(){
      // 切换菜单
      this.$emit('setMenuState')
    }
  }
};
</script>
<style scoped>
.header {
  position: relative;
  top: 0;
  left: 0;
  right: 0;
  height: 40px;
  z-index: 9999999;
  padding: 0 10px;
  line-height: 40px;
  font-size: 24px;
  color: #fff;
  text-align: center;
  background: #c1c1c1;
  transition: transform 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
}
.header.show{
   transform: translateX(250px);
}
.header .icon {
  position: absolute;
  left: 10px;
  top: 0;
}
.header .el-icon-s-unfold {
  font-size: 24px;
  /* color: #c1c1c1; */
}

</style>
