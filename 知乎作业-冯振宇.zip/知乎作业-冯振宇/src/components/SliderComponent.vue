<template>
  <div>
    <!-- 轮组组件 -->
       <el-carousel trigger="click"  height="2.2rem" >
        <el-carousel-item v-for="item in carouselList" :key="item.id">
          <h3 class="title">{{ item.title }}</h3>
          <img class="image" :src="item.image">
        
        </el-carousel-item>
      </el-carousel>
  </div>
</template>
<script>
export default {
  props: ['carouselList']
}
</script>

<style scoped>
.image{
  width: 100%;
  height: 100%;
}
.title{
  position: absolute;
  font-size: 20px;
  padding: 20px;
  color: #fff;
  font-weight: 700;
  left: 0;
  bottom: 10px;
}
.el-carousel__indicators{
  padding: 0;
}

</style>
