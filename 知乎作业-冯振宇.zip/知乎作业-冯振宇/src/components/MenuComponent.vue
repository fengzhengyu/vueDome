<template>
  <div class="menu" :class="{'show':menuState}">
    <!-- 菜单组件 -->
    <div class="flex-wrap">
      <div class="login-img">
        <img src="http://hbimg.b0.upaiyun.com/c065df1d800b65464811b5d75e074004c7f2c0222c53-zjNb8j_fw236" alt="头像">
      </div>
      <div class="login-name">请登录</div>
    </div>
    <ul class="flex-wrap btn-nav-list">
      <li class="btn-nav-item">
        <i class="iconfont icon-wujiaoxing"></i>
        <p>收藏</p>
      </li>
      <li class="btn-nav-item">
        <i class="iconfont icon-xiaoxi"></i>
        <p>消息</p>
      </li>
      <li class="btn-nav-item">
        <i class="iconfont icon-setting"></i>
        <p>设置</p>
      </li>
    </ul>
    <ul class="nav-menu">
      <li class="flex-wrap nav-item" @click="$router.push({name:'index'})">
        <i class="iconfont icon-shouye icon1"></i>
        <span>首页</span>
        <i class="iconfont icon-fanhui icon2"></i>
      </li>
    </ul>
    <div class="footer-wrap " >
      <div class="footer-item">
        <i class="iconfont icon-xiazai"></i>
        <span>下载</span>
      </div>
      <div class="footer-item right">
        <i class="iconfont icon-yueliang-copy"></i>
        <span>夜间</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['menuState'],
  data() {
    return {
      isShow: true
    };
  }
};
</script>

<style scoped>
.menu {
  width: 250px;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  background: #232a30;
  color: #94999d;
  visibility: hidden;
  transition-delay: 0.3s;
}
.menu.show {
  visibility: visible;
  transition-delay: 0s;
}

.flex-wrap {
  display: flex;
  align-items: center;
}

.login-img {
   margin: 15px;
   width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
 
}
.login-img img {
  width: 40px;
  height: 40px;
}
.login-name {
  flex: 1;
  font-size: 14px;
  color: #94999d;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  padding-right: 15px;
}
.btn-nav-list{
  justify-content: space-between;
  width: 190px;
  padding: 0 15px;
}
.btn-nav-item{
  text-align: center;
  font-size: 10px;
  color: #8c9195;
}
.btn-nav-item i{
  font-size: 20px;
}

.nav-menu{
  background: #1b2329;
  margin-top: 20px;
   padding: 0;
}
.nav-item{
  padding: 15px 35px 15px 15px;
  color: #fff;
  font-weight: 700;

}
.nav-item span{
  flex: 1;
}
.nav-item .icon1{
    font-weight:normal;
    margin-right: 10px;
}
.nav-item .icon2{
    font-weight:normal;
    color: #4f565b;
}
.footer-wrap{
  position: absolute;
  left: 0;
  bottom: 0;
  padding: 15px 0px 15px 15px;
  display: flex;
  width: 190px;
 
}
 .footer-item{
  flex: 1;
  display: flex;
  align-items: center;
  font-size: 12px;

}
 .footer-item i{
   font-size: 24px;
 }
 .footer-item.right{

     justify-content: flex-end;
 }

</style>
