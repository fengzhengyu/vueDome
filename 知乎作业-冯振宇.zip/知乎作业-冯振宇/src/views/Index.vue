<template>
  <div>
   
    <Menu :menuState="isShow"></Menu>
     <Header 

      :menuState="isShow"
      @setMenuState="getChildMsg"
    ></Header>
    <Main
      :menuState="isShow"
      :newsList="newsList"
      :beforeNewsList="beforeNewsList"
    >
     <Slider :carouselList="carouselList"></Slider>
    </Main>
  </div>
</template>
<script>
import Header from "../components/IndexHeader.vue";
import Menu from "../components/MenuComponent.vue";
import Main from "../components/MainComponent.vue";
import Slider from "../components/SliderComponent.vue";
export default {
  components: {
    Header,
    Menu,
    Main,
    Slider
  },
  data() {
    return {
      isShow: false,
      id: "3892357",
      newsList: [],
      carouselList: [],
      beforeNewsList: []
    };
  },
  created() {
    this.getAllData();
  },
  methods: {
    // 获取首页所有数据所有
    getAllData() {
      this.$axios
        .all([this.getNewData(), this.getBeforeNewData()])
        .then(res => {
          let newsData = res[0].data;
          let beforeData = res[1].data;

          // 轮播数据
          if (newsData.stories) {
            this.carouselList = newsData.top_stories;
             this.carouselList.splice(0,1)
            
          }
          // 最新数据
          if (newsData.stories) {
            this.newsList = newsData.stories;
            
           
          }
       
          if (beforeData.stories) {
            this.beforeNewsList = beforeData.stories;
          }
        });
    },
    // 获取最新数据
    getNewData() {
      return this.$axios({
        url: "/latest",
        methods: "get"
      });
    },
    // 获取遗忘数据
    getBeforeNewData() {
      return this.$axios({
        url: "/before/20191019",
        methods: "get"
      });
    },
    getChildMsg() {
      this.isShow = !this.isShow;
    }
  }
};
</script>
<style>
</style>

