<template>
  <div class="detail">
    <div class="image-wrap">
      <img :src="dataInfo.image" >
      <h1>{{ dataInfo.title }}</h1>
    </div>
    <div v-html="dataInfo.body"></div>
    <div class="detail-footer">
      <ul>
        <li @click="$router.go(-1)"><i class="iconfont icon-toright"></i></li>
        <li><i class="iconfont icon-toright-copy"></i></li>
        <li><i class="iconfont icon-dianzan"></i></li>
        <li><i class="iconfont icon-1"></i></li>
        <li><i class="iconfont icon-icon-"></i></li>
      
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      dataInfo: {}
    };
  },
  created() {
    let id = this.$route.params.id || 0;
    this.getDetailData(id);
   
  },

  updated(){
    // 删除v-html 空白占位标签 
   let div = document.getElementsByClassName('main-wrap')[0];
      div.removeChild(div.children[0])
  },
  methods: {
    getDetailData(id) {
      this.$axios({
        url: "/" + id,
        methods: "get"
      }).then(res => {
        if (res.status == 200) {
          this.dataInfo = res.data;
          // 插入样式
          let link = document.createElement("link");
          link.rel = "stylesheet";
          link.className = "attr-link";
          link.href = this.dataInfo.css[0];
          document.head.appendChild(link);
        }
      });
    }
  },
  beforeRouteLeave (to, from, next) {
    // 移除样式
    let link = document.querySelectorAll('.attr-link')[0];
   document.head.removeChild(link);
   next();
  }
};
</script>

<style scoped>
.image-wrap {
  height: 3.2rem;
  position: relative;
}
.image-wrap img {
  height: 100%;
  width: 100%;
}
.image-wrap h1 {
  position: absolute;
  padding: 10px 20px;
  left: 0;
  right: 0;
  bottom: 0px;
  font-size: 20px;
  color: #fff;
  font-weight: 700;
}
.detail-footer{
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
 
}
.detail-footer ul{
  display: flex;
  background: #fff;
  padding: 0 20px;
 justify-content:space-between;
}
.detail-footer ul li{
  flex: 1;
  text-align: center;
}
.detail-footer ul i{
  font-size: 20px;
  height: 30px;
  color:#cdcdcd;
}

</style>
