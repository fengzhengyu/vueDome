<template>
  <div id="app">
    <router-view class="view"></router-view>
  </div>
</template>

<style>
* {
  margin: 0;
  padding: 0;
}
html,
body {
  height: 100%;
  font-size: 14px;
  font-family: "arial", "微软雅黑";
  overflow: hidden;
  -webkit-text-size-adjust: none;
}

#app,
.view {
  width: 100%;
  height: 100%;
  background: #fff;
  overflow: hidden;
  position: relative;
  overflow-y: auto;
}

li {
  list-style: none;
}
image{
    border: none;
    outline: none;
  }
</style>
